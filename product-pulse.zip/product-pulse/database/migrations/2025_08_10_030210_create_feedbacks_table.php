<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {

        // Create Categories Table
        Schema::create('categories', function (Blueprint $table) {
            $table->id();
            $table->string('name'); // Category name
            $table->string('description');
            $table->timestamps();
        });

        // Create Comments Table
        Schema::create('comments', function (Blueprint $table) {
            $table->id();
            $table->text('content'); // Comment content
            $table->timestamps();
            $table->foreignId('user_id')->constrained()->onDelete('cascade'); // Foreign key to Users table
            $table->integer('upvotes')->default(0); // Number of upvotes for the comment            $table->integer('downvotes')->default(0); // Number of dow
            $table->integer('downvotes')->default(0); // Number of dow
            $table->index(['user_id']);
        });


        // Create Feedbacks Table
        Schema::create('feedback', function (Blueprint $table) {
            $table->id();
            $table->timestamps();
            $table->string('title'); // Title of the feedback
            $table->text('description'); // Description of the feedback
            $table->foreignId('user_id')->constrained()->onDelete('cascade') ; // Foreign key to Users table
            $table->foreignId('category_id')->constrained()->onDelete('cascade'); // Foreign key to Categories table
            $table->foreignId('comment_id')->nullable()->constrained()->onDelete('set null'); // Foreign key to Comments table (nullable)
            $table->enum('status', ['open', 'in_progress', 'resolved', 'closed'])->default('open'); // Status of the feedback
            $table->integer('upvotes')->default(0); // Number of upvotes for the feedback
            $table->integer('downvotes')->default(0); // Number of dow

            $table->index(['user_id', 'category_id']);

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('categories');
        Schema::dropIfExists('comments');
        Schema::dropIfExists('feedbacks');
    }
};
