<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

use App\Models\Category;  
use App\Models\Feedback;
use App\Models\User;

class FeedbackSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Ensure categories exist before creating feedback
        
        if (!Category::count()) {
            Category::factory()->count(5)->create();  // Create some categories
        }

        // Create 10 feedbacks
        Feedback::factory()->count(10)->create();
    }
}
