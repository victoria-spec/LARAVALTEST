<?php

namespace Database\Factories;

use App\Models\Comment;
use App\Models\Feedback;
use App\Models\Category;
use App\Models\User;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Feedback>
 */
class FeedbackFactory extends Factory
{
    
    protected $model = Feedback::class;


    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */

    public function definition(): array
    {
        return [
            // Random User (owner of the feedback)
            'user_id' => User::factory(), // Generate a random user

            // Random Category (the category of the feedback)
            'category_id' => Category::factory(), // Generate a random category

            // Random title for the feedback
            'title' => $this->faker->sentence,

            // Random description for the feedback
            'description' => $this->faker->paragraph,

            // Default status of the feedback
            'status' => 'open',
            
            // Random number of upvotes
            'upvotes' => $this->faker->numberBetween(0, 100),
            
            // Random number of downvotes
            'downvotes' => $this->faker->numberBetween(0, 50),
        ];
    }
}
