<?php

namespace Database\Factories;

use App\Models\Comment;
use App\Models\Feedback;
use App\Models\Category;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Comment>
 */
class CommentFactory extends Factory
{

    protected $model = Comment::class;

    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'user_id' => User::factory(), // Generate a related user using the UserFactory
            'category_id' => Category::factory(), // Generate a related category using the CategoryFactory
            'feedback_id' => Feedback::factory(), // Related feedback from FeedbackFactory
            'content' => $this->faker->paragraph, // Random paragraph as comment content
        ];
    }
}
