import AppLayout from '@/layouts/app-layout';
import { type BreadcrumbItem } from '@/types';
import { Head, Link} from '@inertiajs/react';
import { type SharedData } from '@/types';
import { usePage } from '@inertiajs/react';

import axios from 'axios';
import { useState, useEffect } from 'react';


const breadcrumbs: BreadcrumbItem[] = [
    {
        title: 'Feedback',
        href: '/feedback',
    },
    {
        title: 'Product A',
        href: '/product-a',
    },
];

// Define types for feedback data
interface Feedback {
    id: number;
    title: string;
    description: string;
    user_id: number;
    user: {
      id: number;  
      name: string; 
      email:string; 
    }
    category: {
        id: number;
        name: string; 
    }
    category_id: number;
    created_at: string;
    updated_at: string;
}

type SortDirection = 'asc' | 'desc';

interface SortConfig {
  key: keyof Feedback; 
  direction: SortDirection;
}


function PaginatedFeedbackList({itemsPerPage = 5 }) {
  const { auth } = usePage<SharedData>().props;
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([]); 

  const [loading, setLoading] = useState<boolean>(true); 
  const [error, setError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedFeedback, setSelectedFeedback] = useState<Feedback>(
  {
    id: 0,
    user_id: 0,
    category_id: 0,
    title: "Default Title",
    user: { 
      name: "Default User",
      email: "Default Email",
      id: 1,
    },
    created_at: new Date().toISOString(), 
    updated_at: new Date().toISOString(), 
    category: { 
      name: "Default Category",
      id: 1, 
    },
    description: "Default description.",
  });
  const [isModalOpen, setIsModalOpen] = useState(false); 
  
  const [sortConfig, setSortConfig] = useState<SortConfig>({
    key: 'created_at', 
    direction: 'asc',
  });
 
  
  useEffect(() => {
      
      axios.get('/api/feedbacks') 
          .then(response => {
              setFeedbacks(response.data); 
              setLoading(false); 
          })
          .catch(error => {
              setError('Failed to fetch feedbacks'); 
              setLoading(false);
          });
  }, []);

  
    if (loading) {
        return <div>Loading...</div>;
    }

    
    if (error) {
        return <div>{error}</div>;
    }

  // Pagination logic
  const totalPages = Math.ceil(feedbacks.length / itemsPerPage);
  
  
  const handlePageChange = (page:number) => {
    if (page < 1 || page > totalPages) return;
    setCurrentPage(page);
  };


  
  const sortedFeedbacks = [...feedbacks].sort((a, b) => {
    if (a[sortConfig.key] < b[sortConfig.key]) {
      return sortConfig.direction === 'asc' ? -1 : 1;
    }
    if (a[sortConfig.key] > b[sortConfig.key]) {
      return sortConfig.direction === 'asc' ? 1 : -1;
    }
    return 0;
  });

  const currentFeedbacks = sortedFeedbacks.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const handleSort = (column:keyof Feedback) => {
    let direction = 'asc' as SortDirection;
    if (sortConfig.key === column && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key: column, direction });
  };

  
  const openModal = (feedbacks:any) => {
    setSelectedFeedback(feedbacks);
    setIsModalOpen(true);
  };

  
  const closeModal = () => {
    setIsModalOpen(false);
  };

  return (
    <div className="w-full max-w-screen-lg mx-auto p-4">
      {/* Table Header with Sorting */}
      <table className="w-full table-auto">
        <thead>
          <tr>
            <th
              onClick={() => handleSort('created_at')}
              className="p-2 text-left font-semibold cursor-pointer hover:bg-gray-200"
            >
              Date
              {sortConfig.key === 'created_at' && (sortConfig.direction === 'asc' ? ' ▲' : ' ▼')}
            </th>
            
            <th
              onClick={() => handleSort('category_id')}
              className="p-2 text-left font-semibold cursor-pointer hover:bg-gray-200"
            >
              Category
              {sortConfig.key === 'category_id' && (sortConfig.direction === 'asc' ? ' ▲' : ' ▼')}
            </th>

            <th
              onClick={() => handleSort('user')}
              className="p-2 text-left font-semibold cursor-pointer hover:bg-gray-200"
            >
              User
              {sortConfig.key === 'user_id' && (sortConfig.direction === 'asc' ? ' ▲' : ' ▼')}
            </th>
            
            <th
              onClick={() => handleSort('title')}
              className="p-2 text-left font-semibold cursor-pointer hover:bg-gray-200"
            >
              Title
              {sortConfig.key === 'title' && (sortConfig.direction === 'asc' ? ' ▲' : ' ▼')}
            </th>
          </tr>
        </thead>
        <tbody>
          {currentFeedbacks.map((feedback) => (
            <tr
              key={feedback.id}
              onClick={() => openModal(feedback)}
              className="cursor-pointer hover:bg-gray-100 border-b"
            >
              <td className="p-2">{new Date(feedback.created_at).toLocaleDateString()}</td>
              <td className="p-2">{feedback.category.name}</td>
              <td className="p-2">{feedback.user.name}</td>
              <td className="p-2">{feedback.title}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Pagination Controls */}
      <div className="flex justify-between mt-4 text-sm">
        <button
          onClick={() => handlePageChange(currentPage - 1)}
          disabled={currentPage === 1}
          className="px-4 py-2 bg-gray-300 text-gray-700 rounded-md disabled:bg-gray-400"
        >
          Previous
        </button>

        <span className="px-4 py-2 text-gray-700">
          Page {currentPage} of {totalPages}
        </span>

        <button
          onClick={() => handlePageChange(currentPage + 1)}
          disabled={currentPage === totalPages}
          className="px-4 py-2 bg-gray-300 text-gray-700 rounded-md disabled:bg-gray-400"
        >
          Next
        </button>
      </div>

      {/* Modal Overlay for Feedback Details */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white rounded-lg shadow-lg p-6 max-w-lg w-full relative">
            {/* Close button */}
            <button
              onClick={closeModal}
              className="absolute top-2 right-2 text-gray-600 font-bold text-xl"
            >
            </button>
            <h2 className="text-xl font-semibold mb-4">{selectedFeedback.title}</h2>
            <p><strong>User:</strong> {selectedFeedback.user.name}</p>
            <p><strong>Date:</strong> {new Date(selectedFeedback.created_at).toLocaleDateString()}</p>
            <p><strong>Category:</strong> {selectedFeedback.category.name}</p>
            <p><strong>Title:</strong> {selectedFeedback.title}</p>
            <p><strong>Description:</strong> {selectedFeedback.description}</p>
            
            

            {/* "Exit" or "Back" Button */}
            <button
              onClick={closeModal}
              className="mt-6 w-full py-2 bg-blue-600 text-white font-semibold rounded-md hover:bg-blue-700 transition duration-300"
            >
              Exit
            </button>
          </div>
        </div>
      )}
    </div>
  );
}


export default function ProductA() {
    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <Head title="Product A" />
            <div className="flex h-full flex-1 flex-col gap-4 rounded-xl p-4 overflow-x-auto">
                <div className="mb-4">
                    <h1 className="text-2xl font-bold">Product A Feedback</h1>
                    <p className="text-gray-600">Here you can view and manage feedback for Product A.</p>
                </div>

                 <nav className="flex items-center justify-end gap-4">
                <Link
                    href={route('create-feedback')}
                    className="inline-block rounded-sm border border-transparent px-5 py-1.5 text-sm leading-normal text-[#1b1b18] hover:border-[#19140035] dark:text-[#EDEDEC] dark:hover:border-[#3E3E3A]"
                >
                    Add Feedback...
                </Link> 
            </nav>

                
                <PaginatedFeedbackList />;    
            </div>
        </AppLayout>
    );
}
