import { PlaceholderPattern } from '@/components/ui/placeholder-pattern';
import AppLayout from '@/layouts/app-layout';
import { type BreadcrumbItem } from '@/types';
import { Head } from '@inertiajs/react';
import axios from 'axios';
import { Accordion } from "@/components/ui/accordion"

const breadcrumbs: BreadcrumbItem[] = [
    {
        title: 'Feedback',
        href: '/feedback',
    },
];

axios.defaults.withCredentials = true;


export default function Feedback() {
    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <Head title="Feedback" />
            <div className="flex h-full flex-1 flex-col gap-4 rounded-xl p-4 overflow-x-auto">
                TODO: Implement Feedback Page
                The feedback page is not fully functional yet. Currently, only Product A has been implemented. Other products will be operational after completing the refactoring of Product A. The feedback creation feature is implemented, but comments have not been implemented yet
            </div>
        </AppLayout>
    );
}
