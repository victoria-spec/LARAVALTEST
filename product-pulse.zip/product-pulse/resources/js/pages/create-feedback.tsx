
import axios from 'axios';
import React, { useState, useEffect } from 'react';

interface FeedbackData {
  category_id: string;
  title: string;
  description: string;
}


const CreateFeedback: React.FC = () => {
  const [categories, setCategories] = useState<any[]>([]);
  const [feedback, setFeedback] = useState<FeedbackData>({
    category_id: '',
    title: '',
    description: '',
  });
  const [errors, setErrors] = useState<any>({});
  const [loading, setLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  
  

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await axios.get('/api/categories');
        setCategories(response.data);  // Store categories
      } catch (error) {
        console.error('Error fetching categories', error);
      }
    };

    fetchCategories();
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFeedback((prevFeedback) => ({
      ...prevFeedback,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    setLoading(true);
    setErrors({});
    setSuccessMessage('');

    try {
        
        const response = await axios.post('/api/feedbacks', feedback);

        setSuccessMessage('Feedback submitted successfully!');
        
        window.history.back();
        setFeedback({
            category_id: '',
            title: '',
            description: '',
      });
    } catch (error: any) {
      if (error.response && error.response.data) {
        setErrors(error.response.data.errors || {});
      }
      console.error('Error submitting feedback', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto p-6 border rounded-lg shadow-lg bg-white">
      <h2 className="text-2xl font-semibold text-center mb-6">Submit Feedback</h2>

      {successMessage && <p className="text-green-600 text-center">{successMessage}</p>}

      <form onSubmit={handleSubmit}>
        {/* User ID - Automatically set from logged-in user */}

        {/* Category */}
        <div className="mb-4">
          <label htmlFor="category_id" className="block text-gray-700">Category</label>
          <select
            id="category_id"
            name="category_id"
            value={feedback.category_id}
            onChange={handleChange}
            className="w-full p-2 mt-2 border rounded-md"
          >
            <option value="">Select Category</option>
            {categories.map((category: any) => (
              <option key={category.id} value={category.id}>
                {category.name}
              </option>
            ))}
          </select>
          {errors.category_id && <p className="text-red-600 text-sm">{errors.category_id}</p>}
        </div>

        {/* Title */}
        <div className="mb-4">
          <label htmlFor="title" className="block text-gray-700">Title</label>
          <input
            type="text"
            id="title"
            name="title"
            value={feedback.title}
            onChange={handleChange}
            placeholder="Feedback Title"
            className="w-full p-2 mt-2 border rounded-md"
          />
          {errors.title && <p className="text-red-600 text-sm">{errors.title}</p>}
        </div>

        {/* Description */}
        <div className="mb-4">
          <label htmlFor="description" className="block text-gray-700">Description</label>
          <textarea
            id="description"
            name="description"
            value={feedback.description}
            onChange={handleChange}
            placeholder="Describe your feedback"
            className="w-full p-2 mt-2 border rounded-md"
          />
          {errors.description && <p className="text-red-600 text-sm">{errors.description}</p>}
        </div>

        {/* Submit Button */}
        <div className="mb-4">
          <button
            type="submit"
            disabled={loading}
            className="w-full p-3 bg-blue-500 text-white rounded-md hover:bg-blue-600"
          >
            {loading ? 'Submitting...' : 'Submit Feedback'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default CreateFeedback;