
<?php

use Illuminate\Support\Facades\Route;
use Inertia\Inertia;


Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('feedback', function () {
        return Inertia::render('feedback');
    })->name('feedback');

    Route::get('create-feedback', function () {
        return Inertia::render('create-feedback');
    })->name('create-feedback');

});
