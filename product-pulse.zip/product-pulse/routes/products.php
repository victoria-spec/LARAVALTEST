<?php

use Illuminate\Support\Facades\Route;
use Inertia\Inertia;


Route::middleware(['auth', 'verified'])->group(function () {
    
    Route::get('product-a', function () {
        return Inertia::render('product-a');
    })->name('product-a');

});
