<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Models\Feedback;
use App\Http\Controllers\Api\FeedbackController;
use App\Http\Controllers\Api\CategoryController;


Route::get('/user', function (Request $request) { 
    return $request->user();
})->middleware('auth:sanctum');


Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::middleware('auth:sanctum')->get('/sanctum/csrf-cookie', function () {
    return response()->json(['message' => 'CSRF cookie set']);
});

Route::middleware('auth:sanctum')->group(function () {
    Route::prefix('feedbacks')->group(function () {
        Route::get('/', [FeedbackController::class, 'index']);
        Route::get('/{id}', [FeedbackController::class, 'show']);
        Route::post('/', [FeedbackController::class, 'store']);
        Route::get('/{id}/comments/', function () {
            return response()->json(Feedback::with('comments')->get());
        });
        Route::post('/{id}//', [FeedbackController::class, 'storeComment']);
    });

    Route::prefix('categories')->group(function () {
        Route::get('/', [CategoryController::class, 'index']);
        Route::get('/{id}', [CategoryController::class, 'show']);
        Route::post('/', [CategoryController::class, 'store']);
        Route::put('/{id}', [CategoryController::class, 'update']);
        Route::delete('/{id}', [CategoryController::class, 'destroy']);
    });

});
