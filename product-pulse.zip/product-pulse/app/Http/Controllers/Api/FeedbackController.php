<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;


use App\Models\Feedback;

class FeedbackController extends Controller
{
    // Get all feedbacks
    public function index()
    {
        $feedbacks = Feedback::with(['user:id,name,email', 'category:id,name'])->get();
        return response()->json($feedbacks);
    }

    // Get a specific feedback by ID
    public function show($id)
    {
        return response()->json(Feedback::find($id));
    }

    // Store new feedback
    public function store(Request $request)
    {
        $validated = $request->validate([
            'category_id' => 'required|exists:categories,id',
            'title' => 'required|string|max:255',
            'description' => 'required|string',
        ]);
        $validated['user_id'] = Auth::id(); // Set the authenticated user ID
        $feedback = Feedback::create($validated);

        return response()->json($feedback, 201);
    }

}
