<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Feedback extends Model
{
    use HasFactory;
    
    protected $fillable = [
        'user_id',
        'category_id',
        'title',
        'description',
    ];

    /**
     * Get the comments associated with the feedback.
     */
    public function comments()
    {
        return $this->hasMany(Comment::class); // A feedback can have many comments
    }

    /**
     * Get the user that owns the feedback.
     */
    
    public function user()
    {
        return $this->belongsTo(User::class); // A feedback belongs to one user 
    }

    /**
     * Get the category associated with the feedback.
     */
    public function category()
    {
        return $this->belongsTo(Category::class); // A feedback belongs to one category
    }


}
