<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Category extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'description',
    ];

    /**
     * Get the name of the category.
     */
    public function getNameAttribute(): string
    {
        return $this->attributes['name'] ?? 'Uncategorized'; // Default to 'Uncategorized' if name is not set
    }

    
    /**
     * Get the description of the category.
     */
    public function getDescriptionAttribute(): string
    {
        return $this->attributes['namedescription'] ?? 'Uncategorized'; // Default to 'Uncategorized' if name is not set
    }


    /**
     * Get the feedbacks associated with the category.
     */

    public function feedbacks()
    {
        return $this->hasMany(Feedback::class); // A category can have many feedbacks
    }
}
