<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Comment extends Model
{
    use HasFactory;

    protected $fillable = [
        'feedback_id',
        'user_id',
        'content',
    ];
    
    /**
     * Get the feedback associated with the comment.
     */
    public function feedback()
    {
        return $this->hasOne(Feedback::class); // A comment can belong to one feedback
    }
}
